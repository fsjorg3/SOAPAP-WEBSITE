<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Ajax Poll Script v3.02 [ GPL ]
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : APSMX-302
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<

include( dirname(__FILE__) . '/CPoll.inc.php' );
include( dirname(__FILE__) . '/CIPBlock.inc.php' );
include( dirname(__FILE__) . '/CCookieBlock.inc.php' );

?>