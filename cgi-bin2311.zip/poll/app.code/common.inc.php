<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Ajax Poll Script v3.02 [ GPL ]
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : APSMX-302
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<

//-- sys version
define( 'SYS_VERSION', "1.00" );

//-- app.code
define( 'PATH_APP_CODE', dirname(__FILE__) . "/" );

//-- app.img
define( 'FOLDER_APP_IMG', "app.img" );

//-- files
include( dirname(__FILE__) . '/CJson.inc.php' );
include( dirname(__FILE__) . '/CTClassObject.inc.php' );
include( dirname(__FILE__) . '/CTClassSys.inc.php' );

?>