<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Ajax Poll Script v3.02 [ GPL ]
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : APSMX-302
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<

$_lng[ 'msg:ip-block-reset' ] = "IP block was reset!";
$_lng[ 'msg:ip-block-not-reset' ] = "IP block could not be reset.";
$_lng[ 'msg:cookie-block-reset' ] = "Cookie block was reset!";
$_lng[ 'msg:cookie-block-not-reset' ] = "Cookie block could not be reset.";

?>