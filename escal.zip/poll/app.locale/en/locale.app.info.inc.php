<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Ajax Poll Script v3.02 [ GPL ]
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : APSMX-302
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<

$_lng[ 'app:title' ] = "Ajax Poll Script";
$_lng[ 'app:version' ] = "3.02";
$_lng[ 'app:pid' ] = "APSMX-302";
$_lng[ 'app:homepage' ] = "http://www.phpkobo.com/ajax_poll.php";

?>