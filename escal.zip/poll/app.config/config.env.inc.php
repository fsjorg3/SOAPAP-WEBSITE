<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Ajax Poll Script v3.02 [ GPL ]
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : APSMX-302
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<

//-- Path
$path = dirname(dirname(__FILE__)) . '/';
$_cfg[ 'path-root' ]   = $path;
$_cfg[ 'path-config' ] = $path . 'app.config/';
$_cfg[ 'path-locale' ] = $path . 'app.locale/';
$_cfg[ 'path-data' ] = $path . 'app.data/';

//-- Language
$_cfg['lang-code'] = 'en';

?>